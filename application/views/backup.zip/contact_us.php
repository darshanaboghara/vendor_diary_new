 <style>
     .text-default
     {
         color:<?php echo $site->colour_name;?> !important; 
     }
 </style>
    <noscript>
        <div class="noscript colrw boxshadow">You have not enabled Javascript on your browser, please enable it to use the website</div>
    </noscript>
    <div class="page-header2">
        <div class="container">
            <div class="row">
                <!-- page caption -->
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                    <div class="page-caption2">
                        <h1 class="page-title">Contact us
                        </h1>
                    </div>
                </div>
                <!-- /.page caption -->
            </div>
        </div>
        <!-- page caption -->
    </div>
    <!-- /.page-header -->
    <!-- contact-form -->
    <div class="space-medium bg-white">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <!-- contact-block -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="contact-block">
                            <div class="contact-icon">
                                <i class="far fa-user-circle" >
                                </i>
                            </div>
                            <div class="contact-content">
                                <h3>Customer Support
                                </h3>
                                <p>
                                    <strong>Phone number:
                                    </strong>
                                    <span class="text-default" > <?php echo  $site->contact_no;?> </span>
                                    <br>
                                    <strong>Email Us:
                                    </strong>
                                    <span class="text-default"> <?php echo  $site->contact_email?> </span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- /.contact-block -->
                    <!-- contact-block -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="contact-block">
                            <div class="contact-icon">
                                <i class="fa fa-map-marker-alt">
                                </i>
                            </div>
                            <div class="contact-content">
                                <h3>Our Address
                                </h3>
                                <p>
                                    <strong>Address:
                                    </strong><span class="text-default" ><?php echo  $site->full_address;?></span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- /.contact-block -->
                    <!-- contact-block -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="contact-block">
                            <div class="contact-icon">
                                <i class="far fa-envelope">
                                </i>
                            </div>
                            <div class="contact-content">
                                <h3>Other Enquiries
                                </h3>
                                <p>Please contact us at the email below for all other inquiries.
                                </p>
                                <p>
                                    <strong>Email Us:
                                    </strong>
                                    <span class="text-default"><?php echo  $site->contact_email?> </span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- /.contact-block -->
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb20">
                            <!-- contact-section-title -->
                            <div class="text-center">
                                <p class="lead mb0">Let's Get In Touch!</p>
                                <p>We always love to hear from our customers! We are happy to answer your questions and assist you</p>
                            </div>
                            <!-- /.contact-section-title -->
                        </div>
                        <div class="col-xl-12 offset-lg-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <form name="contact_us" method="post" action="<?echo base_url();?>Customercomment">
                                <!-- form -->
                                <div class="contact-form">
                                    <div class="row">
                                        <!-- Text input-->
                                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                            <div class="form-group service-form-group">
                                                <label class="control-label sr-only" for="email">
                                                </label>
                                                <input id="name" type="text" name="name" placeholder="Full Name" class="form-control" value="" data-valid="required" required>
                                            </div>
                                        </div>
                                        <!-- Text input-->
                                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                            <div class="form-group service-form-group">
                                                <label class="control-label sr-only" for="email">
                                                </label>
                                                <input id="email" type="email" name="email" value="" placeholder="Email" class="form-control" data-valid="required" required>
                                            </div>
                                        </div>
                                        <!-- Text input-->
                                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                            <div class="form-group service-form-group">
                                                <label class="control-label sr-only" for="mobile_number">
                                                </label>
                                                <input id="mobile_number" type="text" name="mobile_number" placeholder="Mobile Number" value="" class="form-control" maxlength="10" data-valid="required" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                            <!-- textarea -->
                                            <div class="form-group">
                                                <label class="control-label sr-only" for="message">
                                                </label>
                                                <textarea class="form-control" id="desc" name="desc" rows="3" placeholder="Write Comment" data-valid="required" maxlength="500" required></textarea>
                                            </div>
                                        </div>
                                        <!--button -->
                                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                            <button type="submit" name="contactus" id="contactus" onclick="ContactUS.QueryForm(event);" class="btn btn-default">submit
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.form -->
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.contact-form -->
    <!-- contact-block-section -->
</html>