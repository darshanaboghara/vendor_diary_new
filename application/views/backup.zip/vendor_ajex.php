<!--<div class="col-xl-9 col-lg-9 col-md-8 col-sm-12 col-12" id="data">-->
                <?php
                if ($vendors == null) {
                    echo "No data found";
                } else {
                    //die( base_url());

                    foreach ($vendors as $data) {
                ?>
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 float-left slideExpandUp">
                            <div class="vendor-thumbnail">
                                <!-- Vendor thumbnail -->
                                <div class="vendor-img zoomimg">
                                    <a id="img<?php echo $data->id ?>"  href=<?php echo base_url() . "Vendor_details?vid=" . $data->id ?> target="_blank">
                                        <!--<img src="<?php echo base_url() ?>assets/images/<?php echo $data->image; ?>" alt="" class="img-fluid">-->
                                         
                                                 <?php $r=rand(1,40);?>
                                                 <img src='<?php echo (file_exists(IMAGELINK . $data->image))? base_url() . IMAGELINK . $data->image : base_url()."assets/images/wedding-planner/$r.jpeg";  ?>'  alt="Vendor Image Not Found" class="img-fluid">
                                    </a>
                                    <!-- demo.jpg -->
                                </div>
                                <div class="vendor-content">
                                    <!-- Vendor Content -->
                                    <div class="vendor-line">
                                        <div class="vendor-detail1">
                                            <p class="vendor-location" title="<?php echo $data->address ?>" style="white-space: nowrap; 
  overflow: hidden;
  text-overflow: ellipsis; ">
                                                <i class="fa fa-map-marker-alt"></i>
                                                <?php if($data->address)
                                                {
                                                    echo $data->address;
                                                }
                                                else
                                                {
                                                    echo "<del>Not found</del>";
                                                }
                                                ?>
                                            <h2 class="vendor-title ellipsis"><a href='<?php echo base_url() . "Vendor_details?vid=" . $data->id ?>' class="title" target="_blank">
                                                <?php if($data->planner_name)
                                                {
                                                    echo $data->planner_name;
                                                }
                                                else
                                                {
                                                    echo "<del>Not Found</del>";
                                                }
                                                ?>
                                                </a>
                                            <?php if($data->plan_status=="Paid")
                                            {?>
                                               <img src="https://akam.cdn.jdmagicbox.com/images/icontent/newwap/newprot/jdvrsl_verified.svg" style="-webkit-user-drag: none;"> 
                                            <?php }
                                            ?>
                                            </h2>
                                            <p class="vendor-address"><?php echo $this->OH->getcatnamebyid($data->category_id);?></p>
                                        </div>
                                        <?php //$rating=rand(1,5);
                                        if($data->rating=="")
                                            {
                                                 $rating=0;
                                            }
                                            else
                                            {
                                                
                                                $rating=(int)$data->rating;
                                            }
                                         if ($this->session->googlelogin == TRUE) {?>
                                         <span class="rating-star" >
                                            <?php $rcount=1;
                                            for($i=0;$rating!=$i;$i++)
                                            {
                                                ?><i class="fa fa-star rated" onclick="rating('<?php echo $data->id?>','<?php echo $rcount;?>')"></i><?php
                                                $rcount=$rcount+1;
                                            }
                                            ?>
                                            <?php for($i=0;$i!=5-$rating;$i++)
                                            {
                                                ?><i class="fa fa-star mute_rated" onclick="rating('<?php echo $data->id?>','<?php echo $rcount;?>')"></i><?php
                                                 $rcount=$rcount+1;
                                            }
                                            
                                           
                                            ?>
                                            
                                            <!--<i class="fa fa-star rated"></i>-->
                                            <!--<i class="fa fa-star rated"></i>-->
                                            <!--<i class="fa fa-star rated"></i>-->
                                            <!--<i class="fa fa-star mute_rated"></i>-->
                                            <!--<i class="fa fa-star mute_rated"></i>-->
                                        </span>
                                         <?php
                                             
                                         }
                                         else
                                         {?>
                                             <span class="rating-star" >
                                            <?php $rcount=1;
                                            for($i=0;$rating!=$i;$i++)
                                            {
                                                ?><i class="fa fa-star rated" onclick="alert('You need to login first')"></i><?php
                                                $rcount=$rcount+1;
                                            }
                                            ?>
                                            <?php for($i=0;$i!=5-$rating;$i++)
                                            {
                                                ?><i class="fa fa-star mute_rated" onclick="alert('You need to login first')"></i><?php
                                                 $rcount=$rcount+1;
                                            }
                                            ?>
                                            <!--<i class="fa fa-star rated"></i>-->
                                            <!--<i class="fa fa-star rated"></i>-->
                                            <!--<i class="fa fa-star rated"></i>-->
                                            <!--<i class="fa fa-star mute_rated"></i>-->
                                            <!--<i class="fa fa-star mute_rated"></i>-->
                                        </span>
                                         <?php }
                                         
                                          echo '('.$this->OH->getvendorreview($data->id).')';
                                        ?>
                                        
                                    </div>
                                </div>
                                <div class="vendor-line pricing-enq">
                                    <div class="vendor-btn vendor-detail1">
                                        <a href="#EnquiryPopUp" style="color:<?php echo $site->colour_name;?>;" onclick="EnquiryPopUp('<?php echo $data->id ?>','vender-listing','<?php echo $data->planner_name ?>');"><i class="fa fa-envelope"></i> Send Enquiry</a>
                                    </div>
                                </div>

                                <!-- /.Vendor Content -->
                            </div>
                            <!-- /.Vendor thumbnail -->
                        </div>
                <?php }
                }
                ?>

            <!--</div>-->