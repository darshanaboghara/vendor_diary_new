  <!--  /.are you vendor --><div class="footer">
  <div class="container">
            <div class="row">             
                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="footer-widget">
                        <h3 class="widget-title">About Company </h3>
                        <ul class="listnone">
						<li><a href="<?php echo base_url();?>Contactus/aboutus">About us</a></li>
						<li><a href="<?php echo base_url();?>Contactus">Contact us</a></li>
						<li><a href="<?php echo base_url();?>Contactus/privacyPolicy">Privacy Policy</a></li>
						<li><a href="<?php echo base_url();?>Contactus/privacyPolicy">Terms of Uses</a></li>
						<li><a href="<?php echo base_url();?>Contactus/faq">FAQ</a></li>
						<!--	 <a href='https://writingbachelorthesis.com/'>costs ghostwriter bachelor</a> <script type='text/javascript' src='https://www.freevisitorcounters.com/auth.php?id=8efa85eeeed7d4f2278081c7c9e263a8513dce5f'></script>-->
<!--<script type="text/javascript" src="https://www.freevisitorcounters.com/en/home/counter/870123/t/1"></script>			-->
				      </ul>
                    </div>
                </div>
				 <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="footer-widget">
                        <h3 class="widget-title">
                            Contact Address
                        </h3>
                        <p><i class="fa fa-map-marker-alt"></i><?php echo  $site->full_address?></p>
                        <a href="tel:<?php echo  $site->contact_no;?>"><p class="mb0 " style="color:<?php echo $site->colour_name;?>;"><i class="fa fa-phone-volume"></i>  <?php echo  $site->contact_no;?></p></a>
                       <a href="mailto:<?php echo  $site->contact_email ?>"> <p class="mb0 " style="color:<?php echo $site->colour_name;?>;"><i class="fa fa-envelope"></i>   <?php echo  $site->contact_email?> </p></a>
                    </div>
                </div>
                <!-- /.footer-widget -->
                <!-- /.footer-widget -->
                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-6 col-12">
                    <div class="footer-widget">
                        <h3 class="widget-title">
                            List you Business
                        </h3>
                        <p>Are you vendor ? List your venue and service get more from listing business.</p>
                        <a href="<?php echo base_url();?>Registration" class="btn btn-default btn-sm" style="background:<?php echo $site->colour_name;?>; color:<?php echo $site->font_color;?>;border-color:<?php echo $site->colour_name;?>;">List your Business</a>
                    </div>
                </div>
				<div class="col-xl-3 col-lg-3 col-md-12 col-sm-6 col-12">
				 <div class="footer-widget">
					<h3 class="widget-title"> Follow Us </h3>
					<div class="social-icons">
					<a href="<?php echo  $site->facebook_link;?>" class="icon-square"target="_blank"><i class="fab fa-facebook-f"></i></a>
					<a href="<?php echo  $site->twitter_link;?>" class="icon-square" target="_blank"><i class="fab fa-twitter"></i> </a>
					<a href="<?php echo  $site->linkedin_link;?>" class="icon-square" target="_blank"><i class="fab fa-linkedin"></i></a>
					<a href="<?php echo  $site->google_link;?>" class="icon-square" target="_blank"><i class="fab fa-pinterest"></i></a>
					</div>
				</div>
			  </div>
                <!-- /.footer-widget -->
            </div>
        </div>
    </div>    
<!-- tiny-footer-section -->
<div class="tiny-footer">
	<div class="container">
		<div class="row">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">
				<p><?php echo  $site->footer_text?></p>
			</div>
		</div>
	</div>
 </div>
 

 
<!--<div class="gotohome"><a href="https://www.vakomatrimonial.com/"><img src="<?Php echo base_url();?>assets/images/VAKOLOGO.png"/> vako Home</a></div>-->
<!-- <div class="hiring"><a href="http://tanisha.careersitemanager.com/" target="_blank"><img src="<?Php echo base_url();?>assets/images/VAKOLOGO.png" alt='' id='HP_Bottom_Career_Banner'></a></div> -->
<!-- /.tiny-footer-section --> 
</body>

</html>
<style>
    .icon-square:hover
    {
        background-color: <?php echo $site->colour_name;?>;
        color: <?php echo $site->font_color;?>;
    }
    .footer-widget ul li a:hover
    {
        color: <?php echo $site->colour_name;?>;
    }
</style>
<!-- Start of HubSpot Embed Code -->
  <!--<script type="text/javascript" id="hs-script-loader" async defer src="//js-na1.hs-scripts.com/20288544.js"></script>-->
  <!--https://app.hubspot.com/live-messages/20288544/inbox/-->
<!-- End of HubSpot Embed Code -->

<!-- Start of HubSpot Embed Code -->
  <script type="text/javascript" id="hs-script-loader" async defer src="//js-eu1.hs-scripts.com/25116719.js"></script>
   <!--https://app.hubspot.com/live-messages/25116719/inbox/-->
<!-- End of HubSpot Embed Code -->

<!--Visiter time out start -->
<script>
    setTimeout(function(){
        // location.reload("<?php echo base_url()?>Customerlogin")
         //modal.style.display = "block";
        // window.location.replace('<?php echo base_url()?>Customerlogin');
        
    },5000);
</script>
<script>
 $(document).ready(function() {
    $('.wide').select2();
});
</script>
<style>
    .select2-container--default .select2-selection--single .select2-selection__rendered {
    line-height: 50px !important;
    }
    .select2-container .select2-selection--single {
        height: 50px !important;
    }
    .select2-container--default .select2-selection--single .select2-selection__arrow b{
        top:100% !important;
    }
</style>
