<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $site->web_frienly_name;?> Payment</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo  base_url(); ?>favicons/<?php echo $site->upload_favicon;?>">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />

    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/style.css" />    

    <!-- jQuery is used only for this example; it isn't required to use Stripe -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" />

    <!-- Stripe JavaScript library -->
    <script type="text/javascript" src="https://js.stripe.com/v2/"></script>    
    
    <script type="text/javascript">
        //set your publishable key
        Stripe.setPublishableKey('<?php echo SPK;?>');
        
        //callback to handle the response from stripe
        function stripeResponseHandler(status, response) {
            if (response.error) {
                //enable the submit button
                $('#payBtn').removeAttr("disabled");
                //display the errors on the form
                // $('#payment-errors').attr('hidden', 'false');
                $('#payment-errors').addClass('alert alert-danger');
                $("#payment-errors").html(response.error.message);
            } else {
                var form$ = $("#paymentFrm");
                //get token id
                var token = response['id'];
                //insert the token into the form
                form$.append("<input type='hidden' name='stripeToken' value='" + token + "' />");
                //submit form to the server
                form$.get(0).submit();
            }
        }
        $(document).ready(function() {
            //on form submit
            $("#paymentFrm").submit(function(event) {
                //disable the submit button to prevent repeated clicks
                $('#payBtn').attr("disabled", "disabled");
                
                //create single-use token to charge the user
                Stripe.createToken({
                    number: $('#card_num').val(),
                    cvc: $('#card-cvc').val(),
                    exp_month: $('#card-expiry-month').val(),
                    exp_year: $('#card-expiry-year').val()
                }, stripeResponseHandler);
                
                //submit from callback
                return false;
            });
        });
    </script>

    <script src="https://www.paypal.com/sdk/js?client-id=AYsunRZMiHzxOGDeqZ0SkyFztZae7ozmGwet_EV14k_dj_YVjZtEtWSwWgMojJemZW5GOSiDuZf_eENi&currency=AUD"> // Required. Replace YOUR_CLIENT_ID with your sandbox client ID.
    </script>
	
</head>

<body id="header">


<h1>
    <center >
        <img src="<?php echo  base_url(); ?>assets/images/<?php echo $site->upload_logo;?>" alt="Site Logo">
        <!--<?php echo  $site->web_frienly_name;?>-->
        Payment Getway
    </center>
</h1>
	

<div class="container">
	<div class="row">	
        <?php if($pymts[1]->id==9 && $pymts[1]->status=='APPROVED')
        {?>
            <div class="col-md-4">
            
            <div class="card">
                <div class="card-header bg-success text-white">Payment With Stripe 
                <img src="https://stripe.com/img/about/logos/logos/blue@2x.png" style="height: 30px;" alt="stripe Logo">
                </div>
                <div class="card-body bg-light">
                    <?php if (validation_errors()): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Oops!</strong>
                            <?php echo validation_errors() ;?> 
                        </div>  
                    <?php endif ?>
                    <div id="payment-errors"></div>  
                     <form method="post" id="paymentFrm" enctype="multipart/form-data" action="<?php echo base_url(); ?>Payment/check">
                        <div class="form-group">
                            <input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo set_value('name'); ?>" required>
                        </div>  

                        <div class="form-group">
                            <input type="email" name="email" class="form-control" placeholder="email@you.com" value="<?php echo set_value('email'); ?>" required />
                        </div>

                         <div class="form-group">
                            <input type="number" name="card_num" id="card_num" class="form-control" placeholder="Card Number" autocomplete="off" value="<?php echo set_value('card_num'); ?>" required>
                        </div>
                       
                        
                        <div class="row">

                            <div class="col-sm-8">
                                 <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <input type="text" name="exp_month" maxlength="2" class="form-control" id="card-expiry-month" placeholder="MM" value="<?php echo set_value('exp_month'); ?>" required>
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <input type="text" name="exp_year" class="form-control" maxlength="4" id="card-expiry-year" placeholder="YYYY" required="" value="<?php echo set_value('exp_year'); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="form-group">
                                    <input type="text" name="cvc" id="card-cvc" maxlength="3" class="form-control" autocomplete="off" placeholder="CVC" value="<?php echo set_value('cvc'); ?>" required>
                                </div>
                            </div>
                        </div>
                        

                       

                        <div class="form-group text-right">
                          <button class="btn btn-secondary" type="reset">Reset</button>
                          <button type="submit" id="payBtn" class="btn btn-success">Submit Payment</button>
                        </div>
                    </form>     
    <!--                <script src="https://polyfill.io/v3/polyfill.min.js?version=3.52.1&features=fetch"></script>-->
    <!--<script src="https://js.stripe.com/v3/"></script>-->
    <!-- <section>-->
    <!--  <div class="product">-->
    <!--    <img-->
    <!--      src="https://i.imgur.com/EHyR2nP.png"-->
    <!--      alt="The cover of Stubborn Attachments"-->
    <!--    />-->
    <!--    <div class="description">-->
    <!--      <h3>Stubborn Attachments</h3>-->
    <!--      <h5>$20.00</h5>-->
    <!--    </div>-->
    <!--  </div>-->
    <!--  <form action="<?php base_url();?>chekoutnewbtn" method="POST">-->
    <!--    <button type="submit" id="checkout-button">Checkout</button>-->
    <!--  </form>-->
    <!--</section>-->
                    <form action="<?php echo base_url(); ?>Payment/check" method="POST">
													<script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
													data-key="<?php echo $pymts[1]->key;?>"
													data-amount="<?php echo $this->session->Total*100?>"
													data-name="<?php echo $site->web_frienly_name;?>"
													data-description="Plan Name:<?php echo $this->session->data['plandata']->rates_name;?> $ <?php echo $this->session->data['plandata']->plan_amount;?>(AUD)"
													data-image="http://vendordiary.com/favicons/HAE3aKvP.png"
													data-currency="usd"
													></script>
									</form>
                </div>
            </div>
                 
        </div>
        <?php }?>
        
        
        <?php if($pymts[0]->id==1 && $pymts[0]->status=='APPROVED')
        {?>
            <div class="col-md-4">
        	<div class="card">
        		<h6 class="card-header bg-warning text-black">
        			Payment With Paypal
        			 <img src="https://www.paypalobjects.com/digitalassets/c/website/logo/full-text/pp_fc_hl.svg" style="height: 30px;" alt="stripe Logo">
        		</h6>
        		<div class="card-body">
        			<!--<p>Get some real help by browsing these guide from offical source.</p>-->
        			<!--Paypal Button-->
                                       <div id="paypal-button-container"></div>
                                      <script>
                                    //       paypal.Buttons({
                                    //         createOrder: function(data, actions) {
                                    //           // This function sets up the details of the transaction, including the amount and line item details.
                                    //           return actions.order.create({
                                    //             purchase_units: [{
                                    //               amount: {
                                    //                 value: '<?php echo $this->session->data['plandata']->plan_amount;?>'
                                    //               }
                                    //             }]
                                    //           });
                                    //         }
                                    //       }).render('#paypal-button-container');
                                         </script>
                                        <script>
                                              paypal.Buttons({
                                                createOrder: function(data, actions) {
                                                  // This function sets up the details of the transaction, including the amount and line item details.
                                                  return actions.order.create({
                                                    purchase_units: [{
                                                      amount: {
                                                        value: '<?php echo $this->session->data['plandata']->plan_amount;?>'
                                                      }
                                                    }]
                                                  });
                                                },
                                                onApprove: function(data, actions) {
                                                  // This function captures the funds from the transaction.
                                                   xhttp = new XMLHttpRequest();
 xhttp.onreadystatechange = function() {
  if (this.status == 302) {
	window.location('<?php echo base_url();?>Dashboard');
  }
 };
  var url="<?php echo base_url();?>";
 xhttp.open("GET", url+"Payment/acceptPayment", true);
xhttp.send();
                                                  return actions.order.capture().then(function(details) {
                                                    // This function shows a transaction success message to your buyer.
                                                    alert('Transaction completed by ' + details.payer.name.given_name);
                                                    //window.location('<?php echo base_url();?>Dashboard/showVendorPlan');
                                                    window.location.replace('<?php echo base_url();?>Dashboard/showVendorPlan');
                                                    
                                                  });
                                                },
                                                onCancel: function (data) {
    // Show a cancel page, or return to cart
  }
                                              }).render('#paypal-button-container');
                                              //This function displays Smart Payment Buttons on your web page.
                                              
                                            </script>
                                      <!--Paypal Button End-->
        		</div>
        	</div>
        </div>
        <?php }?>
        
        
        <div class="col-md-4">
        	<div class="card">
        		<h6 class="card-header bg-primary text-white">
        			Plan Details
        		</h6>
        		<div class="card-body">
        			<!--<p>Get some real help by browsing these guide from offical source.</p>-->
        			<ul>
        				<!--<li> <a href="https://stripe.com/docs" target="_blank">Stripe Docs</a> </li>-->
        				<!--<li> <a href="https://stripe.com/docs/checkout" target="_blank">Stripe Checkout</a></li>-->
        				<!--<li> <a href="https://stripe.com/docs/error-codes" target="_blank">Stripe Error Codes</a></li>-->
        				<li><b> Plan Name:</b> <?php echo $this->session->data['plandata']->rates_name;?></li>
        				<li><b>Plan Amount:</b>
        				 <?php
                            if($this->session->data['plandata']->plan_amount_type=="INR")
                            {
                                echo "₹";
                            }
                            else if($this->session->data['plandata']->plan_amount_type=="AUD")
                            {
                                echo "$";
                            }
                            else
                            {
                                echo "$";
                            }
                        ?>
        				<?php echo $this->session->data['plandata']->plan_amount;?>(<?php echo $this->session->data['plandata']->plan_amount_type;?>)</li>

        			</ul>
        		</div>
        	</div>
        </div>
        
        
        

    </div>
</div> 

   

 <!--Footer -->
 <footer class="footer" id="header-content">
  <div class="container">
    <!--Copyright &copy; <?php echo date('Y'); ?>  -->
        <span class="float-right">
            <!--Coded with Love &hearts;  : -->
        <?php echo $site->footer_text;?>
        <a href="#<?php echo base_url();?>" ><b><?php echo  $site->web_frienly_name;?></b></a></span>
  </div>
</footer>

</body>
</html>
<style>
    #header {
  position: relative;
  min-height: 650px;
}

#header-content {
  position: absolute;
  bottom: 0;
  left: 0;
}
</style>